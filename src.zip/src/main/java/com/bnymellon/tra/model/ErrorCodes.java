package com.bnymellon.tra.model;



	public enum ErrorCodes {

		TRA1001("TRA1001"),
		TRA1002("TRA1002"),
		TRA1003("TRA1003"),
		TRA1004("TRA1004"),
		TRA1005("TRA1005"),
		TRA1006("TRA1006"),
		TRA1007("TRA1007"),
		TRA1008("TRA1008"),
		TRA1009("TRA1009"),
		TRA1010("TRA1010"),
		TRA1011("TRA1011"),
		TRA1012("TRA1012"),
		TRA1013("TRA1013"),
		TRA1014("TRA1014"),
		TRA1015("TRA1015"),
		TRA1016("TRA1016"),
		TRA1017("TRA1017"),
		TRA1018("TRA1018"),
		TRA1019("TRA1019"),
		TRA1020("TRA1020");
		

		
	public String getErrorcode() {
			return errorcode;
		}

		
	private ErrorCodes(String errorcode) {
			this.errorcode = errorcode;
		}

		
	private String errorcode;
		
		
	}

	

